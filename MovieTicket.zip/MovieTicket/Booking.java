// Booking.java
public class Booking {
    private Customer customer;
    private Movie movie;
    private int numberOfSeats;
    private double totalCost;

    public Booking(Customer customer, Movie movie, int numberOfSeats) {
        this.customer = customer;
        this.movie = movie;
        this.numberOfSeats = numberOfSeats;
        this.totalCost = movie.getCost() * numberOfSeats;
    }

    public boolean processPayment(Payment paymentMethod) {
        return paymentMethod.makePayment(totalCost);
    }

    public double getTotalCost() {
        return totalCost;
    }
}
