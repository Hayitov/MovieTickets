// Customer.java
public class Customer {
    private String name;
    private String phoneNumber;
    private double balance;

    public Customer(String name, String phoneNumber, double balance) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.balance = balance;
    }

    // Getters and setters
    public String getName() { return name; }
    public String getPhoneNumber() { return phoneNumber; }
    public double getBalance() { return balance; }

    public void deductBalance(double amount) {
        balance -= amount;
    }
}
