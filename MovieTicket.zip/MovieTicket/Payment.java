// Payment.java
public interface Payment {
    boolean makePayment(double amount);
}
